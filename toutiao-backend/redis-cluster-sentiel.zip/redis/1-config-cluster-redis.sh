#docker network rm redis-cluster
#docker network create redis-cluster

for port in $(seq 7000 7005); 
do 
mkdir -p /home/wz/redis/node-${port}/conf
touch /home/wz/redis/node-${port}/conf/redis.conf
cat  << EOF > /home/wz/redis/node-${port}/conf/redis.conf
port ${port}
requirepass 1234
bind 0.0.0.0
protected-mode no
daemonize no
appendonly yes
cluster-enabled yes 
cluster-config-file nodes.conf
cluster-node-timeout 5000
cluster-announce-ip 127.0.0.1
cluster-announce-port ${port}
cluster-announce-bus-port 1${port}
EOF
done

