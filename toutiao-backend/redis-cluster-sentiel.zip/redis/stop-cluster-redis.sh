for port in $(seq 7000 7005); 
do 
docker stop redis-cluster-${port}
done

