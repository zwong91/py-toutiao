for port in $(seq 7000 7005); 
do 
docker rm redis-cluster-${port}
done

